//
//  Airplane.swift
//  Chapter 8 Airplane
//
//  Created by Mini Projects on 20/12/2015.
//  Copyright © 2015 Packt Pub. All rights reserved.
//

import Foundation
import CoreLocation
import MapKit
import CoreMotion

protocol AirplaneDelegate {
    func hasMoved(airplane:Airplane)
}

class Airplane {
    
    class Annotation:NSObject, MKAnnotation {
        private var airplane:Airplane!
        
        @objc var coordinate: CLLocationCoordinate2D {
            return airplane.location.coordinate
        }
        
        var direction: Double {
            return airplane.direction
        }
        
        // Title and subtitle for use by selection UI.
        @objc var title: String? { return "Airplane" }
    }
    
    var location:CLLocation!
    var direction:Double
    var delegate:AirplaneDelegate?
    let annotation:Airplane.Annotation?
    private let speed = 0.0001
    private var timer:NSTimer!
    private var motionManager = CMMotionManager()
    
    init(){
        self.direction = 90
        annotation = Airplane.Annotation()
        annotation?.airplane = self
    }
    
    func takeOffFrom(location:CLLocation){
        self.location = location
        self.timer = NSTimer.scheduledTimerWithTimeInterval(0.2, target: self, selector: Selector("move:"), userInfo: nil, repeats: true)
        motionManager.startAccelerometerUpdates()
    }
    
    
    func turnLeft(){
        direction += 1
    }
    
    func turnRight(){
        direction -= 1
    }
    
    @objc func move(userInfo: AnyObject?){
        
        let directionRadians = direction * M_PI / 180.0
        
        let xOffset = cos(directionRadians) * speed
        let yOffset = sin(directionRadians) * speed
        
        let longitude = self.location.coordinate.longitude.advancedBy(xOffset)
        let latitude = self.location.coordinate.latitude.advancedBy(yOffset)
        self.location = CLLocation(latitude: latitude, longitude: longitude)
        print(self.location.coordinate)
        self.delegate?.hasMoved(self)
        if let accelerationData = self.motionManager.accelerometerData {
            if abs(accelerationData.acceleration.y) > 0.25 {
                if accelerationData.acceleration.y > 0{
                    self.turnLeft()
                } else {
                    self.turnRight()
                }
            }
        }
    }
    
    
    deinit{
        self.timer.invalidate()
    }
    
}