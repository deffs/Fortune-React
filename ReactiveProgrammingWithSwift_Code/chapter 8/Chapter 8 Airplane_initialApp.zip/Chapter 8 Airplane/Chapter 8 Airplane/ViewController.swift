//
//  ViewController.swift
//  Chapter 8 Airplane
//
//  Created by Mini Projects on 20/12/2015.
//  Copyright © 2015 Packt Pub. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate, AirplaneDelegate  {
    
    @IBOutlet weak var webview: UIWebView!
    @IBOutlet weak var mapView: MKMapView!
    
    var locationManager = CLLocationManager()
    var airplane = Airplane()
    var geocoder = CLGeocoder()
    var previousCity = ""
    var lastTimeGeocoder:NSDate?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        mapView.delegate = self
        if CLLocationManager.authorizationStatus() != CLAuthorizationStatus.AuthorizedWhenInUse{
            locationManager.requestWhenInUseAuthorization()
        }
        airplane.delegate = self
        
        
    }
    
    
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        if locations.count > 0 {
            locationManager.stopUpdatingLocation()
            let span = MKCoordinateSpanMake(180 / pow(2, 10) * Double(mapView.frame.size.height) / 256.0, 0)
            mapView.setRegion(MKCoordinateRegionMake(locations.first!.coordinate, span), animated:false)
            airplane.takeOffFrom(locations.first!)
            mapView.addAnnotation(airplane.annotation!)
        }
    }
    
    func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
        if status == .AuthorizedWhenInUse {
            locationManager.startUpdatingLocation()
            mapView.showsUserLocation = false
        }
    }
    
    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {
        if let annotation = annotation as? Airplane.Annotation {
            let identifier = "airplane"
            var mkAnnotationView:MKAnnotationView?
            mkAnnotationView = mapView.dequeueReusableAnnotationViewWithIdentifier(identifier)
            if mkAnnotationView == nil
            {
                mkAnnotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            }
            
            
            mkAnnotationView!.image = UIImage(named: "airplane")?.imageRotatedByDegrees(CGFloat(-(airplane.direction - 90)), flip: false)
            
            
            let offset:CGPoint = CGPoint(x: 0, y: -mkAnnotationView!.image!.size.height / 2)
            mkAnnotationView!.centerOffset = offset
            
            return mkAnnotationView!
            
        }
        return nil
    }
    
    
    
    func hasMoved(airplane:Airplane) {
        mapView.removeAnnotation(airplane.annotation!)
        mapView.addAnnotation(airplane.annotation!)
        let span = MKCoordinateSpanMake(180 / pow(2, 10) * Double(mapView.frame.size.height) / 256.0, 0)
        mapView.setRegion(MKCoordinateRegionMake(airplane.annotation!.coordinate, span), animated:true)
        if lastTimeGeocoder == nil || lastTimeGeocoder!.timeIntervalSinceNow < -10 {
            lastTimeGeocoder = NSDate()
            geocoder.reverseGeocodeLocation(airplane.location) { [weak self] (placemarks:[CLPlacemark]?, error:NSError?) -> Void in
                if let error = error {
                    print(error.localizedDescription)
                    return
                }
                if let placemark = placemarks?.first,
                    addressDictionary = placemark.addressDictionary,
                    city = addressDictionary["City"] as? String
                {
                    if city != self?.previousCity {
                        print(city)
                        self?.previousCity = city
                        if let url = NSURL(string: "https://www.google.com/search?btnI=I&q=wikipedia%20\(city)"){
                            let request = NSURLRequest(URL: url)
                            self?.webview.loadRequest(request)
                        }
                    }
                }
                
            }
        }
    }
    
    
}

