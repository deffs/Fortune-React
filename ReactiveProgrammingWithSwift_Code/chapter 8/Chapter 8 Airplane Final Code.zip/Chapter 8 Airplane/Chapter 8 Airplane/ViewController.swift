//
//  ViewController.swift
//  Chapter 8 Airplane
//
//  Created by Mini Projects on 20/12/2015.
//  Copyright © 2015 Packt Pub. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit
import ReactiveCocoa
import AirplaneFramework

class ViewController: UIViewController, MKMapViewDelegate {
    
    @IBOutlet weak var webview: UIWebView!
    @IBOutlet weak var mapView: MKMapView!
    
    var locationManager = CLLocationManager()
    var airplane = Airplane()
    var geocoder = CLGeocoder()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.delegate = self
        
        let authChanged = locationManager.rac_authStatusChanged()
        
        authChanged.filter({ (input:CLAuthorizationStatus) -> Bool in
            return input == .NotDetermined
        }).startWithNext { [weak self](auth:CLAuthorizationStatus) -> () in
            self?.locationManager.requestWhenInUseAuthorization()
        }
        
        authChanged.filter { (input:CLAuthorizationStatus) -> Bool in
            return input == .AuthorizedWhenInUse
            }.startWithNext { [weak self](auth:CLAuthorizationStatus) -> () in
                self?.locationManager.startUpdatingLocation()
                self?.mapView.showsUserLocation = false
        }
        
        let tenSecondsSignal = SignalProducer<Void, NoError>(value: ())
            .delay(10, onScheduler: QueueScheduler(queue: dispatch_get_main_queue()))
        
        
        locationManager.rac_updateLocation()
            .filter({ (locations:[CLLocation]) -> Bool in
                return locations.count > 0
            })
            .take(1)
            .flatMap(FlattenStrategy.Latest, transform: { [weak self](locations:[CLLocation]) -> SignalProducer<Airplane, NSError> in
                if self != nil {
                    self!.locationManager.stopUpdatingLocation()
                    let span = MKCoordinateSpanMake(180 / pow(2, 10) * Double(self!.mapView.frame.size.height) / 256.0, 0)
                    self!.mapView.setRegion(MKCoordinateRegionMake(locations.first!.coordinate, span), animated:false)
                    
                    return self!.airplane.rac_takeOffSignal(locations.first!)
                }
                return SignalProducer<Airplane, NSError>.empty
                })
            .flatMap(FlattenStrategy.Merge, transform: { [weak self](airplane:Airplane) -> SignalProducer<Airplane, NSError> in
                if self != nil {
                    return SignalProducer<Airplane, NSError>({ [weak self] (observer:Observer<Airplane, NSError>, disposable:CompositeDisposable) -> () in
                        if self != nil {
                            self!.mapView.removeAnnotation(airplane.annotation!)
                            self!.mapView.addAnnotation(airplane.annotation!)
                            let span = MKCoordinateSpanMake(180 / pow(2, 10) * Double(self!.mapView.frame.size.height) / 256.0, 0)
                            self!.mapView.setRegion(MKCoordinateRegionMake(airplane.annotation!.coordinate, span), animated:true)
                            observer.sendNext(airplane)
                        }
                        })
                }
                return SignalProducer<Airplane, NSError>.empty
                })
            .sampleOn(tenSecondsSignal)
            .flatMap(FlattenStrategy.Latest, transform: { [weak self] (airplane:Airplane) -> SignalProducer<String, NSError> in
                return SignalProducer<String, NSError>({ [weak self](observer:Observer<String, NSError>, disposable:CompositeDisposable) -> () in
                    if self != nil {
                        self!.geocoder
                            .reverseGeocodeLocation(airplane.location) { (placemarks:[CLPlacemark]?, error:NSError?) -> Void in
                                if let error = error {
                                    print(error.localizedDescription)
                                    return
                                }
                                if let placemark = placemarks?.first,
                                    addressDictionary = placemark.addressDictionary,
                                    city = addressDictionary["City"] as? String
                                {
                                    observer.sendNext(city)
                                }
                        }
                    }
                    
                    })
                })
            .skipRepeats()
            .startWithNext({[weak self] city in
                if let url = NSURL(string: "https://www.google.com/search?btnI=I&q=wikipedia%20\(city)"){
                    let request = NSURLRequest(URL: url)
                    self?.webview.loadRequest(request)
                }
                })// end startWithNext
        
    }
    
    
    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {
        if let annotation = annotation as? Airplane.Annotation {
            let identifier = "airplane"
            var mkAnnotationView:MKAnnotationView?
            mkAnnotationView = mapView.dequeueReusableAnnotationViewWithIdentifier(identifier)
            if mkAnnotationView == nil
            {
                mkAnnotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            }
            
            
            mkAnnotationView!.image = UIImage(named: "airplane")?.imageRotatedByDegrees(CGFloat(-(airplane.direction - 90)), flip: false)
            
            
            let offset:CGPoint = CGPoint(x: 0, y: -mkAnnotationView!.image!.size.height / 2)
            mkAnnotationView!.centerOffset = offset
            
            return mkAnnotationView!
            
        }
        return nil
    }
    
    
    
}

