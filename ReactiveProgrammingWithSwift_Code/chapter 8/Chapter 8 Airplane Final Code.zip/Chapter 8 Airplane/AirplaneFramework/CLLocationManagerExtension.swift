//
//  CLLocationManagerExtension.swift
//  Chapter 8 Airplane
//
//  Created by Mini Projects on 20/12/2015.
//  Copyright © 2015 Packt Pub. All rights reserved.
//

import Foundation
import CoreLocation
import ReactiveCocoa

extension CLLocationManager: CLLocationManagerDelegate {
    
    public func rac_authStatusChanged() -> SignalProducer<CLAuthorizationStatus, NSError> {
        if delegate == nil {
            self.delegate = self
        }
        return self.rac_signalForSelector(
            Selector("locationManager:didChangeAuthorizationStatus:"),
            fromProtocol: CLLocationManagerDelegate.self)
            .toSignalProducer()
            .map { (input:AnyObject?) -> CLAuthorizationStatus in
                let tuple = input as! RACTuple
                if let value = tuple.second as? NSNumber{
                    return CLAuthorizationStatus(rawValue: value.intValue)!
                }else {
                    return CLAuthorizationStatus.NotDetermined
                }
        }
        
        
    }
    
    public func rac_updateLocation() -> SignalProducer<[CLLocation], NSError> {
        if delegate == nil {
            self.delegate = self
        }
        return self.rac_signalForSelector(Selector("locationManager:didUpdateLocations:"), fromProtocol: CLLocationManagerDelegate.self)
            .toSignalProducer()
            .map({ (input: AnyObject?) -> [CLLocation] in
                let tuple = input as! RACTuple
                return tuple.second as! [CLLocation]

        })
    }
    
    
}