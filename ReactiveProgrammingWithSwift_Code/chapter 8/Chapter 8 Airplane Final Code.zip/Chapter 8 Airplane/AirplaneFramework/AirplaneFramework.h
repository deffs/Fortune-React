//
//  AirplaneFramework.h
//  AirplaneFramework
//
//  Created by Mini Projects on 20/12/2015.
//  Copyright © 2015 Packt Pub. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AirplaneFramework.
FOUNDATION_EXPORT double AirplaneFrameworkVersionNumber;

//! Project version string for AirplaneFramework.
FOUNDATION_EXPORT const unsigned char AirplaneFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AirplaneFramework/PublicHeader.h>


