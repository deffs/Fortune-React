//
//  NSTimerExtension.swift
//  Chapter 8 Airplane
//
//  Created by Mini Projects on 21/12/2015.
//  Copyright © 2015 Packt Pub. All rights reserved.
//

import Foundation
import ReactiveCocoa

extension NSTimer {
    public class func rac_signalWithRepeatedInterval(interval:NSTimeInterval) -> SignalProducer<Void, NoError>{
        return SignalProducer<Void, NoError>(
            { (observer:Observer<Void, NoError>, disposable:CompositeDisposable) -> () in
                let fireDate = CFAbsoluteTimeGetCurrent()
                let timer = CFRunLoopTimerCreateWithHandler(kCFAllocatorDefault, fireDate, interval, 0, 0, { (timer:NSTimer!) -> Void in
                    observer.sendNext()
                })
                CFRunLoopAddTimer(CFRunLoopGetCurrent(), timer, kCFRunLoopCommonModes)
        })
    }
}
