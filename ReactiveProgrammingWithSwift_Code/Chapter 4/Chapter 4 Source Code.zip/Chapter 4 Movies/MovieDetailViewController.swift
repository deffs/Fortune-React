//
//  MovieDetailViewController.swift
//  Chapter 4 Movies
//
//  Created by Mini Projects on 06/03/2016.
//  Copyright © 2016 Packt Pub. All rights reserved.
//

import UIKit
import ReactiveCocoa

class MovieDetailViewController: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var posterImage: UIImageView!
    @IBOutlet weak var genreLabel: UILabel!
    @IBOutlet weak var overviewText: UITextView!
    @IBOutlet weak var dismissButton: UIButton!
    
    var movieDetail:[String:AnyObject]!
    let apiKey = "a22160e11a5de46dc792f6d2fa8b434a"
    var posterUrl:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        titleLabel.text = movieDetail["title"] as? String
        overviewText.text = movieDetail["overview"] as? String
        
        if let baseUrl = posterUrl, posterPath = movieDetail["poster_path"] as? String,  url = NSURL(string: baseUrl + posterPath),
            data = NSData(contentsOfURL: url) {
                self.posterImage.image = UIImage(data: data)
        }
        
        let buttonSignal = dismissButton
            .rac_signalForControlEvents(.TouchUpInside)
            .map { (input: AnyObject!) -> AnyObject! in
                return true
        }
        self.rac_liftSelector(Selector("dismissViewControllerAnimated:completion:"), withSignalsFromArray: [buttonSignal, RACSignal.`return`(nil)])
        
        
        
        getGenreSignal().deliverOn(RACScheduler.mainThreadScheduler())
            .subscribeNext { (input:AnyObject!) -> Void in
                let json = input as! [String:[[String:AnyObject]]]
                let genres = self.movieDetail["genre_ids"] as! [Int]
                let genre = json["genres"]?.filter({ (element: [String : AnyObject]) -> Bool in
                    let id = element["id"] as! Int
                    return genres.contains(id)
                }).map({ (element: [String : AnyObject]) -> String in
                    return element["name"] as! String
                })
                
                self.genreLabel.text = genre?.joinWithSeparator(", ")
        } // end subscribeNext
    } // end viewDidLoad
    
    
    private func getGenreSignal() -> RACSignal {
        let url = NSURL(string: "https://api.themoviedb.org/3/genre/movie/list?api_key=\(self.apiKey)")!
        return RACSignal.createSignal({ (subscriber: RACSubscriber!) -> RACDisposable! in
            let task = NSURLSession.sharedSession().dataTaskWithURL(url) {
                (data:NSData?, response: NSURLResponse?, error: NSError?) -> Void in
                guard error == nil else {
                    subscriber.sendError(error!)
                    return
                }
                guard let data = data else {
                    subscriber.sendError(NSError(domain: "app", code: 1, userInfo: nil))
                    return
                }
                
                do {
                    let json = try NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions(rawValue: 0))
                    subscriber.sendNext(json)
                    subscriber.sendCompleted()
                }catch let raisedError as NSError {
                    subscriber.sendError(raisedError)
                }
                
            } // end dataTaskWithURL
            task.resume()
            return RACDisposable(block: { () -> Void in
                task.cancel()
            })
        })
    } // end getGenreSignal
    
} // end MovieDetailViewController
