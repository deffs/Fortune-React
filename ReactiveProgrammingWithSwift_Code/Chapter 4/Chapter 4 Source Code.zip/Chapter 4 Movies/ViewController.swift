//
//  ViewController.swift
//  Chapter 4 Movies
//
//  Created by Mini Projects on 23/10/2015.
//  Copyright © 2015 Packt Pub. All rights reserved.
//

import UIKit
import ReactiveCocoa

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var tableView: UITableView!
    
    lazy dynamic var movieResult = [[String:AnyObject]]()
    let apiKey = "a22160e11a5de46dc792f6d2fa8b434a"
    
    dynamic var posterUrl:String?
    var posterUrlBig:String?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.dataSource = self
        
        self.getPosterSignal()
            .delay(20)
            .subscribeNext { (input) -> Void in
                let tuple = input as! RACTuple
                
                let url = tuple.first as! String
                let urlBig = tuple.second as! String
                self.posterUrl = url
                self.posterUrlBig = urlBig
                
        }
        
        
        let movieResultSignal = self.rac_valuesForKeyPath("movieResult", observer: self)
        movieResultSignal.subscribeNext { (input) -> Void in
            print("Reloading data...")
            self.tableView.reloadData()
        }
        
        
        
        
        
        textField.rac_textSignal()
            .filter({ (input) -> Bool in
                let text = input as! String
                return text.characters.count >= 2
            })
            .throttle(0.6)
            .flattenMap({ (input) -> RACStream! in
                let text = input as! String
                return self.signalForQuery(text)
            })
            .deliverOn(RACScheduler.mainThreadScheduler())
            .subscribeNext({ (input) -> Void in
                let result = input as! [String:AnyObject]
                self.movieResult = result["results"] as! [[String:AnyObject]]
                self.tableView.reloadData()
                }, error: { (error) -> Void in
                    let alertController = UIAlertController(title: "Error",
                        message: error.localizedDescription,
                        preferredStyle: .Alert)
                    let alertAction = UIAlertAction(title: "Dismiss",
                        style: .Cancel, handler: nil)
                    alertController.addAction(alertAction)
                    self.presentViewController(alertController,
                        animated: true, completion: nil)
                    
            })
        
        let tableViewSignal = self.rac_signalForSelector(Selector("tableView:didSelectRowAtIndexPath:"), fromProtocol: UITableViewDelegate.self ).map({ (input:AnyObject!) -> AnyObject! in
            let arguments = input as! RACTuple
            let indexPath = arguments.second as! NSIndexPath
            return self.movieResult[indexPath.row]
        })
        
        /*
         tableViewSignal.subscribeNext { (input) -> Void in
            let movie = input as! [String : AnyObject]
            let title = movie["original_title"] as! String
            print("You have chosen the movie: \(title)")
            self.performSegueWithIdentifier("movie_detail", sender: self)
        }
         */

        self.rac_liftSelector(Selector("performSegueWithIdentifier:sender:"), withSignalsFromArray:  [RACSignal.`return`("movie_detail"), tableViewSignal])
        
        self.rac_signalForSelector(Selector("prepareForSegue:sender:"))
            .filter { (input: AnyObject!) -> Bool in
                let tuple = input as! RACTuple
                let segue = tuple.first as! UIStoryboardSegue
                return segue.destinationViewController is MovieDetailViewController && tuple.second is [String:AnyObject]
            }.subscribeNext { (input) -> Void in
                let tuple = input as! RACTuple
                let segue = tuple.first as! UIStoryboardSegue
                let viewController = segue.destinationViewController as! MovieDetailViewController
                viewController.movieDetail = tuple.second as! [String:AnyObject]
                viewController.posterUrl = self.posterUrl
        }

        
        
        self.tableView.delegate = self
        
    }

    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    private func signalForQuery(query:String) -> RACSignal{
        let encodedQuery = query.stringByAddingPercentEncodingWithAllowedCharacters(.URLHostAllowedCharacterSet())!
        let url = NSURL(string: "https://api.themoviedb.org/3/search/movie?api_key=\(apiKey)&query=\(encodedQuery)")!
        return RACSignal.createSignal(
            { (subscriber:RACSubscriber!) -> RACDisposable! in
                let session = NSURLSession.sharedSession()
                let task = session.dataTaskWithURL(url, completionHandler: { (data, urlResponse, error) -> Void in
                    if let error = error {
                        subscriber.sendError(error)
                    }
                    else {
                        do {
                            let json = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions(rawValue: 0))
                            subscriber.sendNext(json)
                            
                        }catch let raisedError as NSError {
                            subscriber.sendError(raisedError)
                        }
                    }
                    subscriber.sendCompleted()
                })
                
                task.resume()
                return RACDisposable(block: { () -> Void in
                    task.cancel()
                })
        })
    }
    
    
    private func getPosterSignal() -> RACSignal{
        let url = NSURL(string: "https://api.themoviedb.org/3/configuration?api_key=\(apiKey)")!
        let request = NSURLRequest(URL: url)
        let producer = NSURLSession.sharedSession().rac_dataWithRequest(request)
        return RACSignal.createSignal { subscriber in
            let selfDisposable = producer.start { event in
                switch event {
                case let .Next(value, _):
                    subscriber.sendNext(value)
                case let .Failed(error):
                    subscriber.sendError(error)
                case .Completed:
                    subscriber.sendCompleted()
                case .Interrupted:
                    break
                }
            }
            
            return RACDisposable {
                selfDisposable.dispose()
            }
            }
            .retry(5)
            .map({ (input) -> AnyObject! in
                let data = input as! NSData
                let json = try! NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions(rawValue: 0))
                return json
            })
            .map { (input) -> AnyObject! in
                let dictionary = input as! [String:AnyObject]
                let images = dictionary["images"] as! [String:AnyObject]
                let baseUrl = images["secure_base_url"] as! String
                let posterSizes = images["poster_sizes"] as! [String]
                return RACTuple(objectsFromArray: ["\(baseUrl)\(posterSizes[0])", "\(baseUrl)\(posterSizes.last!)"])
        }
        
        
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return movieResult.count;
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCellWithIdentifier("cell")
        if cell == nil {
            cell = UITableViewCell(style: .Default, reuseIdentifier: "cell")
        }
        cell?.textLabel?.text = movieResult[indexPath.row]["original_title"] as? String
        
        self.rac_valuesForKeyPath("posterUrl", observer: self)
            .subscribeOn(RACScheduler(priority: RACSchedulerPriorityLow))
            .map { (input) -> AnyObject! in
                if let baseUrl = input as? String, poster = self.movieResult[indexPath.row]["poster_path"] as? String, url = NSURL(string: baseUrl + poster),
                    data = NSData(contentsOfURL: url) {
                        return UIImage(data: data)
                }
                return UIImage()
            }
            .deliverOn(RACScheduler.mainThreadScheduler())
            .subscribeNext { (input) -> Void in
                let image = input as! UIImage
                let cell = tableView.cellForRowAtIndexPath(indexPath)
                cell?.imageView?.image = image
                cell?.setNeedsLayout()
        }
        
        return cell!
    }
    
    
}

