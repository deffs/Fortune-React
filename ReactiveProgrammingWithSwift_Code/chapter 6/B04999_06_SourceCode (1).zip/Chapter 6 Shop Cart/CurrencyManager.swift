//
//  CurrencyManager.swift
//  Chapter 6 Shop Cart
//
//  Created by Mini Projects on 25/11/2015.
//  Copyright © 2015 Packt Pub. All rights reserved.
//

import Foundation
import ReactiveCocoa


final class CurrencyManager:NSObject {
    private static var instance:CurrencyManager?
    private static var dispatch_once_token:dispatch_once_t = 0
    
    
    dynamic lazy var currentCurrency:Currency = Currency(name: "GBP", rate: 1.0)
    var defaultCurrency:Currency {
        return Currency(name: "GBP", rate: 1.0)
    }
    
    
    static func sharedCurrencyManager() -> CurrencyManager {
        dispatch_once(&dispatch_once_token) { () -> Void in
            CurrencyManager.instance = CurrencyManager()
        }
        return instance!
    }

    private override init(){
        super.init()
    }
    
    
    func currencyChangedSignalProducer() -> SignalProducer<Currency, NSError> {
        return self.rac_valuesForKeyPath("currentCurrency", observer: self)
            .toSignalProducer()
            .map({ (input:AnyObject?) -> Currency in
            return input as! Currency
        })
    }
    
    
    func signalForRates() -> Signal<[Currency], NSError> {
        let url = NSURL(string: "http://api.fixer.io/latest?base=GBP")!
        let signal = self.signalForUrl(url)
            .map { (input:NSData) -> [String:AnyObject] in
            let json = try! NSJSONSerialization.JSONObjectWithData(input, options: NSJSONReadingOptions.MutableContainers)
                return json["rates"] as! [String: AnyObject]
            }.map { (input:[String : AnyObject]) -> [Currency] in
                var currencies = [Currency]()
                currencies.append(self.defaultCurrency)
                for (key, value) in input {
                    let currency = Currency(name: key, rate: value as! Double)
                    currencies.append(currency)
                }
            return currencies
        }
        
        return signal
    }

    
    private func signalForUrl(url:NSURL) -> Signal<NSData, NSError> {
        let (signal, observer) = Signal<NSData, NSError>.pipe()
        let task = NSURLSession.sharedSession().dataTaskWithURL(url) { (data:NSData?, response:NSURLResponse?, error:NSError?) -> Void in
            if let error = error {
                observer.sendFailed(error)
            }else {
                observer.sendNext(data!)
            }
            observer.sendCompleted()
        }
        task.resume()
        return signal
    }
}
