//
//  ShopCart.swift
//  Chapter 6 Shop Cart
//
//  Created by Mini Projects on 27/11/2015.
//  Copyright © 2015 Packt Pub. All rights reserved.
//

import Foundation
import ReactiveCocoa

class ShopCart:NSObject{

    dynamic var total:Double = 0
    dynamic var userTotal:Double = 0
    var items:NSCountedSet = NSCountedSet()

    private var totalSignal:SignalProducer<Double, NSError>!
    private var userTotalSignal:SignalProducer<Double, NSError>!
    
    override init(){
        super.init()
        
        CurrencyManager.sharedCurrencyManager()
            .currencyChangedSignalProducer()
            .startWithNext { [weak self](currency:Currency) -> () in
            self?.refreshUserTotal()
        }
        
        self.totalSignal = self.rac_valuesForKeyPath("total", observer: self).toSignalProducer().map({ (input:AnyObject?) -> Double in
            return input as! Double
        })
        self.userTotalSignal = self.rac_valuesForKeyPath("userTotal", observer: self).toSignalProducer().map({ (input:AnyObject?) -> Double in
            return input as! Double
        })
        
        self.totalSignal.startWithNext {[weak self] (input:Double) -> () in
            self?.refreshUserTotal()
        }
    }
    
    func addProduct(product:Product) -> Int{
        let currentValue = self.items.countForObject(product)
        items.addObject(product)
        let finalValue = self.items.countForObject(product)
        self.total += Double(finalValue - currentValue) * product.userPrice;
        return finalValue
    }

    func removeProduct(product: Product) -> Int{
        let currentValue = self.items.countForObject(product)
        items.removeObject(product)
        let finalValue = self.items.countForObject(product)
        self.total -= Double(currentValue - finalValue) * product.userPrice
        return finalValue
    }
    
    func signalForUserTotal() -> SignalProducer<Double, NSError> {
        return self.userTotalSignal;
    }
    
    private func refreshUserTotal() {
        let rate = CurrencyManager.sharedCurrencyManager().currentCurrency.rate
        self.userTotal = self.total * rate;
    }
}// end ShopCart

