//
//  ViewController.swift
//  Chapter 6 Shop Cart
//
//  Created by Mini Projects on 19/11/2015.
//  Copyright © 2015 Packt Pub. All rights reserved.
//

import UIKit
import ReactiveCocoa

class ViewController: UIViewController,UITableViewDataSource {
    
    @IBOutlet weak var catalogTableView: UITableView!
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var checkoutButton: UIButton!
    
    var catalog = Catalog()
    var shopCart = ShopCart()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.shopCart.signalForUserTotal()
            .observeOn(UIScheduler())
            .startWithNext {[weak self] (input:Double) -> () in
                let currency = CurrencyManager.sharedCurrencyManager().currentCurrency
                if let weakSelf = self {
                    let totalText = String(format:"Total: %.02f %@", weakSelf.shopCart.userTotal,  currency.name)
                    weakSelf.totalLabel.text = totalText
                }
        }
        
        self.rac_signalForSelector(Selector("prepareForSegue:sender:"))
            .toSignalProducer()
            .map({ (input:AnyObject?) -> RACTuple in
                return input as! RACTuple
            })
            .map({ (arguments:RACTuple) -> UIStoryboardSegue in
                return arguments.first as! UIStoryboardSegue
            })
            .filter({ (segue:UIStoryboardSegue) -> Bool in
                return segue.destinationViewController is CheckoutViewController
            })
            .startWithNext { (segue) -> () in
                let checkoutViewController = segue.destinationViewController as! CheckoutViewController
                    checkoutViewController.shopCart = self.shopCart

        }
        
        self.catalogTableView.dataSource = self
    }//end viewDidLoad
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return self.catalog.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCellWithIdentifier("productcell", forIndexPath: indexPath) as! ProductCell
        let product = self.catalog[indexPath.row]
        cell.nameLabel.text = product.description
        
        // Every time the price changes we have to refresh the price label
        product.userPriceSignal
            .observeOn(UIScheduler())
            .startWithNext { [weak cell] (double:Double) -> () in
            let currency = CurrencyManager.sharedCurrencyManager().currentCurrency
            let priceText = String(format:"For only %.02f %@", product.userPrice, currency.name)
            cell?.priceLabel.text = priceText
        }
        
        // add product
        cell.addButton
            .rac_signalForControlEvents(.TouchUpInside)
            .toSignalProducer()
            .on(next:{[weak self, weak cell] (_) -> () in
                if let weakSelf = self {
                    let numberOfItems = weakSelf.shopCart.addProduct(product)
                    cell?.numberOfItemsLabel.text = String(format:"%d", numberOfItems)
                    cell?.numberOfItemsLabel.sizeToFit()
                }
                })
            .start()
        
        // remove product
        cell.removeButton
            .rac_signalForControlEvents(.TouchUpInside)
            .toSignalProducer()
            .on(next: {[weak self, weak cell] (_) -> () in
            if let weakSelf = self {
                let numberOfItems = weakSelf.shopCart.removeProduct(product)
                cell?.numberOfItemsLabel.text = String(format:"%d", numberOfItems)
                cell?.numberOfItemsLabel.sizeToFit()
            }
            })
            .start()
        
        if let imageName = product.imageName {
            cell.productImage.image = UIImage(named:imageName)
        }
        return cell
    } // end cellForRowAtIndexPath
    
    
} // end ViewController

