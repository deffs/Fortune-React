//
//  Catalog.swift
//  Chapter 6 Shop Cart
//
//  Created by Mini Projects on 26/11/2015.
//  Copyright © 2015 Packt Pub. All rights reserved.
//

import Foundation

class Catalog {
    private var items = [Product]()
    var count:Int {
        return items.count
    }
    
    init() {
        var product = Product(code: "1")
        product.name = "Peas"
        product.price = 0.95
        product.type = .Bag
        product.imageName = "peas"
        self.items.append(product)
        
        product = Product(code:"2")
        product.name = "Eggs"
        product.price = 2.10
        product.type = .DozenLikeWhenYouBuyBananas;
        product.imageName = "eggs";
        self.items.append(product)
        
        product = Product(code:"3")
        product.name = "Milk"
        product.price = 1.30
        product.type = .Bottle
        product.imageName = "milk"
        self.items.append(product)
        
        product = Product(code:"4")
        product.name = "Beans"
        product.price = 0.73;
        product.type = .Can;
        product.imageName = "beans";
        self.items.append(product)
    }

    subscript(index:Int) -> Product {
        return items[index]
    }

    func indexForCode(code:String) -> Int? {
        for (index, value) in items.enumerate() {
            if value.code == code {
                return index
            }
        }
        return nil
    }
}