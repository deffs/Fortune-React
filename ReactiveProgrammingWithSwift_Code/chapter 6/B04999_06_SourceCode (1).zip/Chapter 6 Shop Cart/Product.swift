//
//  Product.swift
//  Chapter 6 Shop Cart
//
//  Created by Mini Projects on 26/11/2015.
//  Copyright © 2015 Packt Pub. All rights reserved.
//

import Foundation
import ReactiveCocoa

enum  ProductUnitType {
    case Unknown
    case Bag
    case Can
    case Bottle
    case DozenLikeWhenYouBuyBananas
}

class Product:NSObject {
    var code:String
    var name:String?
    dynamic var price:Double = 0
    dynamic var userPrice:Double = 0
    var type:ProductUnitType = .Unknown
    var imageName:String?
    
    var priceSignal:SignalProducer<Double, NSError>!
    var userPriceSignal:SignalProducer<Double,NSError>!
    
    override var description: String {
        let unit:String
        switch self.type {
        case .Bag:
            unit = "Bag of "
        case .Bottle:
            unit = "Bottle of "
        case .Can:
            unit = "Can of "
        case .DozenLikeWhenYouBuyBananas:
            unit = "Dozen of ";
        default:
            unit = ""
        }
        
        let name:String
        if let _ = self.name {
           name = self.name!
        }else {
            name = ""
        }
        
        return "\(unit)\(name)"
    }
    

    
    init(code:String){
        self.code = code
        super.init()
        
        self.priceSignal = self.rac_valuesForKeyPath("price", observer: self).toSignalProducer().map({ (input) -> Double in
            return input as! Double
        })
        
        priceSignal.startWithNext { [weak self](price) -> () in
            self?.refreshUserPrice()
        }
        
        CurrencyManager.sharedCurrencyManager()
            .currencyChangedSignalProducer()
            .startWithNext { [weak self](currency:Currency) -> () in
            self?.refreshUserPrice()
        }

        self.userPriceSignal = self.rac_valuesForKeyPath("userPrice", observer: self)
            .toSignalProducer()
            .map({ (input:AnyObject?) -> Double in
            return input as! Double
        })
    } // end init
    
    func refreshUserPrice (){
        let rate = CurrencyManager.sharedCurrencyManager().currentCurrency.rate
        self.userPrice = rate * self.price
    }

}// end Product