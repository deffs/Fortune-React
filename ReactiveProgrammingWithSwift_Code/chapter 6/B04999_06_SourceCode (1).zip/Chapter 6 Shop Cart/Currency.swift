//
//  Currency.swift
//  Chapter 6 Shop Cart
//
//  Created by Mini Projects on 22/11/2015.
//  Copyright © 2015 Packt Pub. All rights reserved.
//

import Foundation


class Currency:NSObject{
    var name:String
    var rate:Double
    
    static var baseCurrency:Currency = {
        return Currency(name:"GBP", rate: 1.0)
    }()
    
    init(name: String, rate:Double){
        self.name = name
        self.rate = rate
    }
}
