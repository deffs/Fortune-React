//
//  ProductCell.swift
//  Chapter 6 Shop Cart
//
//  Created by Mini Projects on 22/11/2015.
//  Copyright © 2015 Packt Pub. All rights reserved.
//

import Foundation
import UIKit

class ProductCell:UITableViewCell {
    @IBOutlet weak var nameLabel:UILabel!
    @IBOutlet weak var priceLabel:UILabel!
    @IBOutlet weak var productImage:UIImageView!
    @IBOutlet weak var addButton:UIButton!
    @IBOutlet weak var removeButton:UIButton!
    @IBOutlet weak var numberOfItemsLabel:UILabel!

}

