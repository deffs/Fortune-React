//
//  CheckoutViewContoller.swift
//  Chapter 6 Shop Cart
//
//  Created by Mini Projects on 28/11/2015.
//  Copyright © 2015 Packt Pub. All rights reserved.
//

import Foundation
import UIKit
import ReactiveCocoa

class CheckoutViewController: UIViewController,UITableViewDataSource {


    
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var changeCurrencyButton:UIButton!
    @IBOutlet weak var productsTableView:UITableView!
    @IBOutlet weak var totalLabel:UILabel!
    
    private class PurchasedProduct {
        var product:Product
        var quantity:Int
        init(product:Product, quantity:Int){
            self.product = product
            self.quantity = quantity
        }
    }
    private lazy var purchasedProducts = [PurchasedProduct]()
    var shopCart:ShopCart!

    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.purchasedProducts = shopCart.items
            .reduce([PurchasedProduct](),
                combine: { (var purchasedProducts:[PurchasedProduct], item:AnyObject) -> [PurchasedProduct] in
                    let product = item as! Product
                    let quantity = self.shopCart.items.countForObject(product)
                    let purchasedProduct = PurchasedProduct(product: product, quantity: quantity)
                    purchasedProducts.append(purchasedProduct)
                    return purchasedProducts
            })

        self.backButton
            .rac_signalForControlEvents(.TouchUpInside)
            .toSignalProducer()
            .startWithNext { [weak self](_) -> () in
            self?.dismissViewControllerAnimated(true, completion: nil)
        }
        
        self.changeCurrencyButton
            .rac_signalForControlEvents(.TouchUpInside)
            .toSignalProducer()
            .flatMap(FlattenStrategy.Concat) { (_) -> Signal<[Currency], NSError> in
                return CurrencyManager.sharedCurrencyManager().signalForRates()
            }
            .observeOn(UIScheduler())
            .on(failed: { [weak self] (_:NSError) -> () in
                self?.showNoInternet()
                }) { [weak self] (input:[Currency]) -> () in
                    self?.showRates(input)
            }
            .start()

        
        self.shopCart
            .signalForUserTotal()
            .observeOn(UIScheduler())
            .startWithNext { [weak self] (input:Double) -> () in
                if let weakSelf = self {
                    let currency = CurrencyManager.sharedCurrencyManager().currentCurrency
                    let totalText = String(format:"Total: %.02f %@", weakSelf.shopCart.userTotal, currency.name)
                    weakSelf.totalLabel.text = totalText;
                }
        }
        
        self.productsTableView.dataSource = self
    } // end viewDidLoad
    
    
    // MARK: - Table view data source
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return self.purchasedProducts.count
    }
    

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
        var cell = tableView.dequeueReusableCellWithIdentifier("cell")
        if cell == nil {
            cell = UITableViewCell(style: .Subtitle, reuseIdentifier: "cell")
        }
        let purchasedProduct = self.purchasedProducts[indexPath.row]
        
        // observing any price changing
        purchasedProduct.product.userPriceSignal
            .observeOn(UIScheduler())
            .on { [weak cell](input:Double) -> () in
            let currency = CurrencyManager.sharedCurrencyManager().currentCurrency
            let total = purchasedProduct.product.userPrice * Double(purchasedProduct.quantity)
            cell?.textLabel?.text = String(format: "%d %@ for %.02f %@",purchasedProduct.quantity, purchasedProduct.product.description, total, currency.name)
        }.start()
        
        return cell!
    }
    
    
    // MARK: - Private
    private func showRates(rates:[Currency]) {
        let alertController = UIAlertController(title: "Change Currency", message: "Please choose your currency", preferredStyle: .ActionSheet)
        
        for currency in rates {
            let action = UIAlertAction(title: currency.name, style: .Default, handler: { (_) -> Void in
                CurrencyManager.sharedCurrencyManager().currentCurrency = currency
            })
            alertController.addAction(action)
        }
        
        let action = UIAlertAction(title: "Cancel", style: .Cancel, handler: nil)
        alertController.addAction(action)
        self.presentViewController(alertController, animated: true, completion: nil)
    }
    
    private func showNoInternet() {
        let alertController = UIAlertController(title: "Error", message: "Unable to retrieve currencies", preferredStyle: .Alert)
        let action = UIAlertAction(title: "Dismiss", style: .Cancel, handler: nil)
        alertController.addAction(action)
        self.presentViewController(alertController, animated: true, completion: nil)
    }

} // end Checkout View Controller
