//
//  ViewController.swift
//  RAC from Carthage
//
//  Created by Mini Projects on 04/10/2015.
//  Copyright © 2015 Packt Pub. All rights reserved.
//

import UIKit
import ReactiveCocoa

class ViewController: UIViewController {

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textField.rac_textSignal().subscribeNext { text in
            self.label.text = text as? String
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

